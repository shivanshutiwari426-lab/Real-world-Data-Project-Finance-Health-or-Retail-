"""
Generate a realistic synthetic retail sales dataset.

Simulates 3 years of daily sales across:
- 5 stores (different regions, different baseline traffic)
- 6 product categories (with different seasonality/price points)
Includes: growth trend, weekly seasonality, yearly seasonality (holidays),
promotions, price, and noise -- similar structure to real POS data.
"""
import numpy as np
import pandas as pd

np.random.seed(42)

start = pd.Timestamp("2023-01-01")
end = pd.Timestamp("2025-12-31")
dates = pd.date_range(start, end, freq="D")

stores = {
    "Store_A_NY": 1.30,   # relative baseline traffic multiplier
    "Store_B_LA": 1.15,
    "Store_C_CHI": 1.00,
    "Store_D_HOU": 0.85,
    "Store_E_MIA": 0.95,
}

categories = {
    "Electronics":    {"base_price": 180, "base_units": 8,  "yearly_amp": 0.9, "weekly_amp": 0.15},
    "Apparel":        {"base_price": 45,  "base_units": 25, "yearly_amp": 0.5, "weekly_amp": 0.35},
    "Home & Garden":  {"base_price": 60,  "base_units": 15, "yearly_amp": 0.35,"weekly_amp": 0.25},
    "Groceries":      {"base_price": 12,  "base_units": 90, "yearly_amp": 0.1, "weekly_amp": 0.30},
    "Toys":           {"base_price": 25,  "base_units": 12, "yearly_amp": 1.4, "weekly_amp": 0.20},  # huge Nov/Dec spike
    "Beauty":         {"base_price": 35,  "base_units": 18, "yearly_amp": 0.3, "weekly_amp": 0.20},
}

rows = []
for d in dates:
    day_of_year = d.dayofyear
    weekday = d.weekday()  # 0=Mon
    years_elapsed = (d - start).days / 365.25

    # Overall business growth trend (~10% per year)
    trend = 1 + 0.10 * years_elapsed

    # Holiday boost windows
    holiday_boost = 1.0
    if (d.month == 11 and d.day >= 20) or (d.month == 12 and d.day <= 24):
        holiday_boost = 1.9  # Black Friday -> Christmas
    elif d.month == 12 and d.day in (26, 27, 28, 29, 30, 31):
        holiday_boost = 1.3  # post-Christmas sales
    elif d.month == 7 and 1 <= d.day <= 7:
        holiday_boost = 1.25  # July 4th sales
    elif d.month == 1 and d.day <= 5:
        holiday_boost = 1.15  # New Year sales

    # Random promo days (~8% of days, store-category specific handled below)
    for store, store_mult in stores.items():
        for cat, p in categories.items():
            # weekly seasonality (weekend lift)
            weekly = 1 + p["weekly_amp"] * (1 if weekday >= 5 else -0.3)
            # yearly seasonality (sinusoidal, phase-shifted per category)
            yearly = 1 + p["yearly_amp"] * np.sin(2 * np.pi * (day_of_year - 80) / 365.25) * (0.3) \
                     if cat != "Toys" else 1 + 0.15 * np.sin(2 * np.pi * (day_of_year - 80) / 365.25)

            promo = np.random.rand() < 0.07
            promo_mult = np.random.uniform(1.3, 1.8) if promo else 1.0

            noise = np.random.normal(1, 0.12)

            units = (p["base_units"] * store_mult * trend * weekly * yearly
                     * holiday_boost * promo_mult * noise)
            units = max(0, np.random.poisson(max(units, 0.1)))

            price = p["base_price"] * np.random.normal(1, 0.03)
            if promo:
                price *= np.random.uniform(0.75, 0.9)  # discount during promo

            revenue = round(units * price, 2)

            rows.append([d, store, cat, units, round(price, 2), revenue, promo])

df = pd.DataFrame(rows, columns=[
    "date", "store", "category", "units_sold", "unit_price", "revenue", "promo_flag"
])

df.to_csv("/home/claude/retail_project/data/retail_sales.csv", index=False)
print(df.shape)
print(df.head())
print("\nDate range:", df.date.min(), "to", df.date.max())
print("Total revenue: ${:,.0f}".format(df.revenue.sum()))
