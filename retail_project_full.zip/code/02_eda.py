import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

plt.rcParams.update({
    "figure.dpi": 140,
    "font.size": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
})
sns.set_palette("Set2")

df = pd.read_csv("/home/claude/retail_project/data/retail_sales.csv", parse_dates=["date"])
df["month"] = df["date"].dt.to_period("M").astype(str)
df["weekday"] = df["date"].dt.day_name()
df["year"] = df["date"].dt.year

CH = "/home/claude/retail_project/charts/"

# ---------- 1. Overall daily revenue trend ----------
daily = df.groupby("date")["revenue"].sum().reset_index()
daily["ma30"] = daily["revenue"].rolling(30).mean()

fig, ax = plt.subplots(figsize=(11, 4.5))
ax.plot(daily["date"], daily["revenue"], color="#8fbcd4", alpha=0.4, linewidth=0.7, label="Daily revenue")
ax.plot(daily["date"], daily["ma30"], color="#1b4965", linewidth=2, label="30-day moving avg")
ax.set_title("Daily Revenue Trend (2023–2025)", fontsize=13, fontweight="bold")
ax.set_ylabel("Revenue ($)")
ax.legend(frameon=False)
plt.tight_layout()
plt.savefig(CH + "01_revenue_trend.png")
plt.close()

# ---------- 2. Revenue by category ----------
cat_rev = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 5))
cat_rev.plot(kind="barh", ax=ax, color=sns.color_palette("Set2", len(cat_rev)))
ax.set_title("Total Revenue by Category (2023–2025)", fontsize=13, fontweight="bold")
ax.set_xlabel("Revenue ($)")
ax.invert_yaxis()
for i, v in enumerate(cat_rev):
    ax.text(v, i, f"  ${v/1e6:.1f}M", va="center", fontsize=9)
plt.tight_layout()
plt.savefig(CH + "02_revenue_by_category.png")
plt.close()

# ---------- 3. Revenue by store ----------
store_rev = df.groupby("store")["revenue"].sum().sort_values(ascending=False)
fig, ax = plt.subplots(figsize=(8, 5))
store_rev.plot(kind="bar", ax=ax, color=sns.color_palette("Set2", len(store_rev)))
ax.set_title("Total Revenue by Store (2023–2025)", fontsize=13, fontweight="bold")
ax.set_ylabel("Revenue ($)")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(CH + "03_revenue_by_store.png")
plt.close()

# ---------- 4. Monthly seasonality by category (avg across years) ----------
df["month_num"] = df["date"].dt.month
season = df.groupby(["month_num", "category"])["revenue"].sum().reset_index()
season_pivot = season.pivot(index="month_num", columns="category", values="revenue")
season_pivot = season_pivot.div(season_pivot.sum(axis=0), axis=1) * 100  # normalize to % of yearly total

fig, ax = plt.subplots(figsize=(11, 5))
for cat in season_pivot.columns:
    ax.plot(season_pivot.index, season_pivot[cat], marker="o", markersize=3, label=cat)
ax.set_title("Monthly Seasonality by Category (% share of annual revenue)", fontsize=13, fontweight="bold")
ax.set_xlabel("Month")
ax.set_ylabel("% of category's annual revenue")
ax.set_xticks(range(1, 13))
ax.legend(frameon=False, fontsize=8, ncol=2)
plt.tight_layout()
plt.savefig(CH + "04_seasonality_by_category.png")
plt.close()

# ---------- 5. Weekday pattern ----------
weekday_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
wd = df.groupby("weekday")["revenue"].mean().reindex(weekday_order)
fig, ax = plt.subplots(figsize=(8, 4.5))
wd.plot(kind="bar", ax=ax, color="#3d5a80")
ax.set_title("Average Daily Revenue by Day of Week", fontsize=13, fontweight="bold")
ax.set_ylabel("Avg revenue ($)")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig(CH + "05_weekday_pattern.png")
plt.close()

# ---------- 6. Promo impact ----------
promo_impact = df.groupby("promo_flag")["units_sold"].mean()
fig, ax = plt.subplots(figsize=(6, 4.5))
promo_impact.rename({True: "Promo Day", False: "Regular Day"}).plot(kind="bar", ax=ax, color=["#94b0c2", "#e07a5f"])
ax.set_title("Avg Units Sold: Promo vs Regular Days", fontsize=13, fontweight="bold")
ax.set_ylabel("Avg units sold (per store-category-day)")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(CH + "06_promo_impact.png")
plt.close()

# ---------- 7. Correlation heatmap ----------
corr_df = df[["units_sold", "unit_price", "revenue", "promo_flag"]].copy()
corr_df["promo_flag"] = corr_df["promo_flag"].astype(int)
fig, ax = plt.subplots(figsize=(5.5, 4.5))
sns.heatmap(corr_df.corr(), annot=True, cmap="coolwarm", center=0, ax=ax, fmt=".2f")
ax.set_title("Correlation Matrix", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig(CH + "07_correlation_heatmap.png")
plt.close()

# ---------- Summary stats for report ----------
summary = {
    "total_revenue": df["revenue"].sum(),
    "total_units": df["units_sold"].sum(),
    "avg_order_value": df["revenue"].sum() / df["units_sold"].sum(),
    "n_days": df["date"].nunique(),
    "top_category": cat_rev.index[0],
    "top_category_rev": cat_rev.iloc[0],
    "bottom_category": cat_rev.index[-1],
    "top_store": store_rev.index[0],
    "top_store_rev": store_rev.iloc[0],
    "promo_lift_pct": (promo_impact[True] / promo_impact[False] - 1) * 100,
    "best_weekday": wd.idxmax(),
    "worst_weekday": wd.idxmin(),
    "yoy_2024_vs_2023": (df[df.year==2024].revenue.sum() / df[df.year==2023].revenue.sum() - 1) * 100,
    "yoy_2025_vs_2024": (df[df.year==2025].revenue.sum() / df[df.year==2024].revenue.sum() - 1) * 100,
}
import json
with open("/home/claude/retail_project/data/eda_summary.json", "w") as f:
    json.dump(summary, f, indent=2, default=str)

for k, v in summary.items():
    print(k, ":", v)
