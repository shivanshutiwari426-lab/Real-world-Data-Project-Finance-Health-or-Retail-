"""
Predictive modeling: forecast total daily revenue.

Approach: aggregate to daily totals, engineer calendar + lag features,
train a Random Forest regressor, evaluate on a held-out final 3 months
(time-based split, not random -- correct practice for time series),
compare against a naive baseline.
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, r2_score

plt.rcParams.update({"figure.dpi": 140, "font.size": 10,
                      "axes.spines.top": False, "axes.spines.right": False})

df = pd.read_csv("/home/claude/retail_project/data/retail_sales.csv", parse_dates=["date"])
daily = df.groupby("date").agg(
    revenue=("revenue", "sum"),
    units=("units_sold", "sum"),
    promo_share=("promo_flag", "mean"),
).reset_index()

# ---- feature engineering ----
daily["dow"] = daily["date"].dt.dayofweek
daily["month"] = daily["date"].dt.month
daily["day"] = daily["date"].dt.day
daily["day_of_year"] = daily["date"].dt.dayofyear
daily["is_weekend"] = (daily["dow"] >= 5).astype(int)
daily["days_since_start"] = (daily["date"] - daily["date"].min()).dt.days

def holiday_window(d):
    if (d.month == 11 and d.day >= 20) or (d.month == 12 and d.day <= 24):
        return 1
    return 0
daily["is_holiday_window"] = daily["date"].apply(holiday_window)

# lag / rolling features (yesterday, last week, trailing avg)
daily["lag_1"] = daily["revenue"].shift(1)
daily["lag_7"] = daily["revenue"].shift(7)
daily["roll_7"] = daily["revenue"].shift(1).rolling(7).mean()
daily["roll_30"] = daily["revenue"].shift(1).rolling(30).mean()
daily = daily.dropna().reset_index(drop=True)

features = ["dow", "month", "day", "day_of_year", "is_weekend", "days_since_start",
            "is_holiday_window", "promo_share", "lag_1", "lag_7", "roll_7", "roll_30"]
target = "revenue"

# time-based split: last 90 days = test
split_date = daily["date"].max() - pd.Timedelta(days=90)
train = daily[daily["date"] <= split_date]
test = daily[daily["date"] > split_date]

X_train, y_train = train[features], train[target]
X_test, y_test = test[features], test[target]

model = RandomForestRegressor(n_estimators=400, max_depth=10, min_samples_leaf=3,
                               random_state=42, n_jobs=-1)
model.fit(X_train, y_train)
pred = model.predict(X_test)

mae = mean_absolute_error(y_test, pred)
mape = mean_absolute_percentage_error(y_test, pred) * 100
r2 = r2_score(y_test, pred)

# naive baseline: predict same as 7 days ago
baseline_pred = test["lag_7"]
mae_base = mean_absolute_error(y_test, baseline_pred)
mape_base = mean_absolute_percentage_error(y_test, baseline_pred) * 100

print(f"Random Forest -> MAE: ${mae:,.0f}, MAPE: {mape:.2f}%, R2: {r2:.3f}")
print(f"Naive (lag-7) -> MAE: ${mae_base:,.0f}, MAPE: {mape_base:.2f}%")

# ---- plot actual vs predicted ----
fig, ax = plt.subplots(figsize=(11, 5))
ax.plot(train["date"].tail(60), train["revenue"].tail(60), color="#94b0c2", label="Train (last 60d)")
ax.plot(test["date"], y_test, color="#1b4965", linewidth=2, label="Actual (test)")
ax.plot(test["date"], pred, color="#e07a5f", linewidth=2, linestyle="--", label="Predicted (Random Forest)")
ax.axvline(split_date, color="gray", linestyle=":", linewidth=1)
ax.set_title(f"Daily Revenue Forecast — Actual vs Predicted (Test MAPE: {mape:.1f}%)",
             fontsize=13, fontweight="bold")
ax.set_ylabel("Revenue ($)")
ax.legend(frameon=False)
plt.tight_layout()
plt.savefig("/home/claude/retail_project/charts/08_forecast_actual_vs_predicted.png")
plt.close()

# ---- feature importance ----
importances = pd.Series(model.feature_importances_, index=features).sort_values(ascending=True)
fig, ax = plt.subplots(figsize=(8, 5.5))
importances.plot(kind="barh", ax=ax, color="#3d5a80")
ax.set_title("Feature Importance — Revenue Forecast Model", fontsize=13, fontweight="bold")
ax.set_xlabel("Importance")
plt.tight_layout()
plt.savefig("/home/claude/retail_project/charts/09_feature_importance.png")
plt.close()

import json
model_summary = {
    "mae": mae, "mape": mape, "r2": r2,
    "baseline_mae": mae_base, "baseline_mape": mape_base,
    "improvement_over_baseline_pct": (1 - mae/mae_base) * 100,
    "test_days": len(test),
    "train_days": len(train),
    "top_features": importances.sort_values(ascending=False).head(5).to_dict(),
}
with open("/home/claude/retail_project/data/model_summary.json", "w") as f:
    json.dump(model_summary, f, indent=2, default=str)
print(json.dumps(model_summary, indent=2, default=str))
